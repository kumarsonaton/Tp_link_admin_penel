# TPCRACKER
TP-Link router cracker!

````
[+] TPCRACKER (1.0.0)
[+] DEVELOPED BY @ITSN0B1T4
[+] TEAM TOXINUM
````

<h3 align="left">INSTALL :</h3>

````bash
pkg update && upgrade -y
pkg install git -y
pkg install python -y
git clone https://github.com/ITSN0B1T4/tpcracker
cd tpcracker
pip install -r requirements.txt
````

## How to use :

````bash
python main.py
````

<div align="center">
<h3>━━━━ Connect with me ━━━━</h3>
<a href="https://fb.com/TOXINUM" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/facebook.svg" alt="TOXIC-VIRUS" height="30" width="40" /></a>
<a href="https://twitter.com/itzakx21" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/twitter.svg" alt="itzakx21" height="30" width="40" /></a>
<a href="https://fb.com/ITSN0B1T4" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/facebook.svg" alt="Mohammad Alamin" height="30" width="40" /></a>
<a href="https://instagram.com/ITSN0B1T4" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="akxvau" height="30" width="40" /></a>
</div>
